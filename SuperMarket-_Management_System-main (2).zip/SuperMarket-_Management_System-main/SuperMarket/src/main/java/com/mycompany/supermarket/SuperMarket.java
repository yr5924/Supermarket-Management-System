/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.supermarket;

import Home.LoginPage;

/**
 *
 * @author yashr
 */
public class SuperMarket {

    public static void main(String[] args) {
         new LoginPage().setVisible(true);
    }                
    }

